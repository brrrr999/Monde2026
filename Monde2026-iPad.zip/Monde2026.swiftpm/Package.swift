// swift-tools-version: 5.9
import PackageDescription
import AppleProductTypes

let package = Package(
    name: "Monde 2026",
    platforms: [.iOS("17.0")],
    products: [
        .iOSApplication(
            name: "Monde 2026",
            targets: ["AppModule"],
            bundleIdentifier: "com.brrrr999.monde2026",
            displayVersion: "0.9",
            bundleVersion: "1",
            appIcon: .placeholder(icon: .map),
            accentColor: .presetColor(.orange),
            supportedDeviceFamilies: [.pad, .phone],
            supportedInterfaceOrientations: [
                .portrait, .landscapeRight, .landscapeLeft,
                .portraitUpsideDown(.when(deviceFamilies: [.pad]))
            ]
        )
    ],
    targets: [
        .executableTarget(
            name: "AppModule",
            path: "Sources",
            resources: [.copy("Resources/map.bin"), .copy("Resources/terrain.json")]
        )
    ],
    swiftLanguageVersions: [.v5]
)
